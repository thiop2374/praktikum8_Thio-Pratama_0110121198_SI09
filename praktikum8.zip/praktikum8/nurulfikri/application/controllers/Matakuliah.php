<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    class Matakuliah extends CI_Controller {

    public function index(){
        $this->load->model('Matakuliah_Model','mk1');

        $this->mk1->id=1;
        $this->mk1->nama='Pemrograman Web 2';
        $this->mk1->sks='3';
        $this->mk1->kode='4001';

        $this->load->model('Matakuliah_Model','mk2');  
        
        $this->mk2->id=2;
        $this->mk2->nama='Jaringan Komputer';
        $this->mk2->sks='3';
        $this->mk2->kode='4002';

        $this->load->model('Matakuliah_Model','mk3');  
        
        $this->mk3->id=3;
        $this->mk3->nama='Statistika & Probabilitas';
        $this->mk3->sks='2';
        $this->mk3->kode='6001';

        $this->load->model('Matakuliah_Model','mk4');  
        
        $this->mk4->id=4;
        $this->mk4->nama='Bahasa Inggris';
        $this->mk4->sks='2';
        $this->mk4->kode='6002';
 
        $list_mk = [$this->mk1, $this->mk2, $this->mk3, $this->mk4];
        $data['list_mk']=$list_mk;
 
        // $this->load->view('header');
        $this->load->view('matakuliah/index',$data);
        // $this->load->view('footer');
 }
}
