<?php
class Matakuliah_Model extends CI_Model {
    public $id;
    public $nama;
    public $sks;
    public $kode;
}